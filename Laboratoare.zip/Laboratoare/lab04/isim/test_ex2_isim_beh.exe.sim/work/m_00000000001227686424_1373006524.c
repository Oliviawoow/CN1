/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "state";
static const char *ng1 = "exp_output";
static const char *ng2 = "C:/Users/student/Desktop/lab/lab04_skel_remote/lab04_skel/lib/helpers.vh";
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {170U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {85U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {4U, 0U};
static unsigned int ng9[] = {5U, 0U};
static unsigned int ng10[] = {129U, 0U};
static unsigned int ng11[] = {6U, 0U};
static unsigned int ng12[] = {66U, 0U};
static unsigned int ng13[] = {7U, 0U};
static unsigned int ng14[] = {36U, 0U};
static unsigned int ng15[] = {8U, 0U};
static unsigned int ng16[] = {24U, 0U};
static unsigned int ng17[] = {9U, 0U};
static unsigned int ng18[] = {10U, 0U};
static unsigned int ng19[] = {11U, 0U};
static unsigned int ng20[] = {12U, 0U};
static unsigned int ng21[] = {105U, 0U};
static unsigned int ng22[] = {13U, 0U};
static unsigned int ng23[] = {141U, 0U};
static unsigned int ng24[] = {14U, 0U};
static unsigned int ng25[] = {139U, 0U};
static unsigned int ng26[] = {15U, 0U};
static unsigned int ng27[] = {255U, 255U};
static const char *ng28 = "Total: %0d/%0d (%1.1Fp)";
static const char *ng29 = "The simulation is canceling...";
static int ng30[] = {0, 0};
static int ng31[] = {1, 0};
static const char *ng32 = "* ";
static const char *ng33 = "_ ";
static const char *ng34 = "C:/Users/student/Desktop/lab/lab04_skel_remote/lab04_skel/test_ex2.v";
static const char *ng35 = "Initial state not found! - FAILED";
static unsigned int ng36[] = {17U, 0U};
static int ng37[] = {3, 0};
static int ng38[] = {16, 0};
static const char *ng39 = "%s : t%d - FAILED";
static int ng40[] = {8, 0};
static const char *ng41 = "%s : t%d - PASSED";
static const char *ng42 = "The machine did not go back to first state. - FAILED";
static const char *ng43 = "The machine did not change at reset. - FAILED";



static void exp_output_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 160U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 3, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng1, 2, 7, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static int sp_exp_output(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    t0 = 1;
    xsi_set_current_line(3, ng2);

LAB2:    xsi_set_current_line(4, ng2);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 160U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);

LAB3:    t8 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 4);
    if (t9 == 1)
        goto LAB4;

LAB5:    t3 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB6;

LAB7:    t3 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB8;

LAB9:    t3 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB10;

LAB11:    t3 = ((char*)((ng9)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB12;

LAB13:    t3 = ((char*)((ng11)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB14;

LAB15:    t3 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB16;

LAB17:    t3 = ((char*)((ng15)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB18;

LAB19:    t3 = ((char*)((ng17)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB20;

LAB21:    t3 = ((char*)((ng18)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB22;

LAB23:    t3 = ((char*)((ng19)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB24;

LAB25:    t3 = ((char*)((ng20)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB26;

LAB27:    t3 = ((char*)((ng22)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB28;

LAB29:    t3 = ((char*)((ng24)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB30;

LAB31:    t3 = ((char*)((ng26)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB32;

LAB33:
LAB35:
LAB34:    xsi_set_current_line(20, ng2);
    t3 = ((char*)((ng27)));
    t4 = (t2 + 96U);
    t5 = *((char **)t4);
    t6 = (t5 + 0U);
    xsi_vlogvar_assign_value(t6, t3, 0, 0, 8);

LAB36:    t0 = 0;

LAB1:    return t0;
LAB4:    xsi_set_current_line(5, ng2);
    t10 = ((char*)((ng4)));
    t11 = (t2 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 0U);
    xsi_vlogvar_assign_value(t13, t10, 0, 0, 8);
    goto LAB36;

LAB6:    xsi_set_current_line(6, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB8:    xsi_set_current_line(7, ng2);
    t4 = ((char*)((ng4)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB10:    xsi_set_current_line(8, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB12:    xsi_set_current_line(9, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB14:    xsi_set_current_line(10, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB16:    xsi_set_current_line(11, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB18:    xsi_set_current_line(12, ng2);
    t4 = ((char*)((ng16)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB20:    xsi_set_current_line(13, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB22:    xsi_set_current_line(14, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB24:    xsi_set_current_line(15, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB26:    xsi_set_current_line(16, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB28:    xsi_set_current_line(17, ng2);
    t4 = ((char*)((ng23)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB30:    xsi_set_current_line(18, ng2);
    t4 = ((char*)((ng25)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB32:    xsi_set_current_line(19, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

}

static int sp_succ_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(29, ng2);

LAB2:    xsi_set_current_line(30, ng2);
    t3 = (t1 + 4136);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4296);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 4136);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 4456);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 4296);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1280);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(31, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_err_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(39, ng2);

LAB2:    xsi_set_current_line(40, ng2);
    t3 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng29, 1, t3);
    xsi_set_current_line(41, ng2);
    t3 = (t1 + 4776);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4936);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 4776);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 5096);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 4936);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(42, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_show_LEDs(char *t1, char *t2)
{
    char t7[8];
    char t20[8];
    char t28[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t0 = 1;
    xsi_set_current_line(50, ng2);

LAB2:    xsi_set_current_line(51, ng2);
    xsi_set_current_line(51, ng2);
    t3 = (t1 + 5576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 5736);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 6);

LAB3:    t3 = (t1 + 5736);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng30)));
    memset(t7, 0, 8);
    t8 = (t5 + 4);
    if (*((unsigned int *)t8) != 0)
        goto LAB5;

LAB4:    t9 = (t6 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB5;

LAB8:    if (*((unsigned int *)t5) > *((unsigned int *)t6))
        goto LAB6;

LAB7:    t11 = (t7 + 4);
    t12 = *((unsigned int *)t11);
    t13 = (~(t12));
    t14 = *((unsigned int *)t7);
    t15 = (t14 & t13);
    t16 = (t15 != 0);
    if (t16 > 0)
        goto LAB9;

LAB10:    t0 = 0;

LAB1:    return t0;
LAB5:    t10 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB9:    xsi_set_current_line(51, ng2);

LAB11:    xsi_set_current_line(52, ng2);
    t17 = (t1 + 5416);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t21 = (t1 + 5416);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t1 + 5736);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = ((char*)((ng31)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_minus(t28, 32, t26, 6, t27, 32);
    xsi_vlog_generic_get_index_select_value(t20, 1, t19, t23, 2, t28, 32, 2);
    t29 = (t20 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (~(t30));
    t32 = *((unsigned int *)t20);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(55, ng2);
    t3 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng33, 1, t3);

LAB14:    xsi_set_current_line(51, ng2);
    t3 = (t1 + 5736);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng31)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_minus(t7, 32, t5, 6, t6, 32);
    t8 = (t1 + 5736);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 6);
    goto LAB3;

LAB12:    xsi_set_current_line(53, ng2);
    t35 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng32, 1, t35);
    goto LAB14;

}

static void Initial_27_0(char *t0)
{
    char t5[8];
    char t46[8];
    char t60[8];
    char t78[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    double t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    int t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    int t74;
    char *t75;
    char *t76;
    char *t77;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;

LAB0:    t1 = (t0 + 6656U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng34);

LAB4:    xsi_set_current_line(29, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3336);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(30, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(33, ng34);
    t2 = (t0 + 6464);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(34, ng34);
    t3 = ((char*)((ng31)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(35, ng34);
    t2 = (t0 + 6464);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(36, ng34);
    t3 = ((char*)((ng30)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(39, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);
    xsi_set_current_line(41, ng34);

LAB7:    t2 = (t0 + 2936U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB11;

LAB8:    if (t16 != 0)
        goto LAB10;

LAB9:    *((unsigned int *)t5) = 1;

LAB11:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB13;

LAB12:    t26 = (t0 + 7224);
    *((int *)t26) = 1;
    t27 = (t0 + 6656U);
    *((char **)t27) = &&LAB7;
    goto LAB1;

LAB10:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB11;

LAB13:    t28 = (t0 + 7224);
    *((int *)t28) = 0;
    xsi_set_current_line(42, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB15;

LAB14:    if (t16 != 0)
        goto LAB16;

LAB17:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB18;

LAB19:
LAB20:    xsi_set_current_line(47, ng34);
    xsi_set_current_line(47, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 3816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB28:    t2 = (t0 + 3816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng38)));
    memset(t5, 0, 8);
    t19 = (t4 + 4);
    if (*((unsigned int *)t19) != 0)
        goto LAB30;

LAB29:    t20 = (t6 + 4);
    if (*((unsigned int *)t20) != 0)
        goto LAB30;

LAB33:    if (*((unsigned int *)t4) < *((unsigned int *)t6))
        goto LAB31;

LAB32:    t27 = (t5 + 4);
    t7 = *((unsigned int *)t27);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB34;

LAB35:    xsi_set_current_line(57, ng34);
    t2 = (t0 + 7272);
    *((int *)t2) = 1;
    t3 = (t0 + 6688);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB62;
    goto LAB1;

LAB15:    *((unsigned int *)t5) = 1;
    goto LAB17;

LAB16:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(42, ng34);

LAB21:    xsi_set_current_line(43, ng34);
    xsi_vlogfile_write(1, 0, 0, ng35, 1, t0);
    xsi_set_current_line(44, ng34);
    t2 = (t0 + 3656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng36)));
    t19 = ((char*)((ng37)));
    t20 = (t0 + 6464);
    t26 = (t0 + 1712);
    t27 = xsi_create_subprogram_invocation(t20, 0, t0, t26, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t26, t27);
    t28 = (t0 + 4776);
    xsi_vlogvar_assign_value(t28, t5, 0, 0, 8);
    t29 = (t0 + 4936);
    xsi_vlogvar_assign_value(t29, t6, 0, 0, 8);
    t30 = (t0 + 5096);
    t31 = ((char*)((ng37)));
    t32 = xsi_vlog_convert_to_real(t31, 32, 1);
    xsi_vlogvar_assign_value_double(t30, t32, 0);

LAB24:    t33 = (t0 + 6560);
    t34 = *((char **)t33);
    t35 = (t34 + 80U);
    t36 = *((char **)t35);
    t37 = (t36 + 272U);
    t38 = *((char **)t37);
    t39 = (t38 + 0U);
    t40 = *((char **)t39);
    t41 = ((int  (*)(char *, char *))t40)(t0, t34);

LAB26:    if (t41 != 0)
        goto LAB27;

LAB22:    t34 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t34);

LAB23:    t42 = (t0 + 6560);
    t43 = *((char **)t42);
    t42 = (t0 + 1712);
    t44 = (t0 + 6464);
    t45 = 0;
    xsi_delete_subprogram_invocation(t42, t43, t0, t44, t45);
    goto LAB20;

LAB25:;
LAB27:    t33 = (t0 + 6656U);
    *((char **)t33) = &&LAB24;
    goto LAB1;

LAB30:    t26 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB32;

LAB31:    *((unsigned int *)t5) = 1;
    goto LAB32;

LAB34:    xsi_set_current_line(47, ng34);

LAB36:    xsi_set_current_line(48, ng34);

LAB37:    t28 = (t0 + 2936U);
    t29 = *((char **)t28);
    t28 = (t0 + 3816);
    t30 = (t28 + 56U);
    t31 = *((char **)t30);
    memset(t46, 0, 8);
    t33 = (t29 + 4);
    t34 = (t31 + 4);
    t12 = *((unsigned int *)t29);
    t13 = *((unsigned int *)t31);
    t14 = (t12 ^ t13);
    t15 = *((unsigned int *)t33);
    t16 = *((unsigned int *)t34);
    t17 = (t15 ^ t16);
    t18 = (t14 | t17);
    t21 = *((unsigned int *)t33);
    t22 = *((unsigned int *)t34);
    t23 = (t21 | t22);
    t24 = (~(t23));
    t25 = (t18 & t24);
    if (t25 != 0)
        goto LAB41;

LAB38:    if (t23 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t46) = 1;

LAB41:    t36 = (t46 + 4);
    t47 = *((unsigned int *)t36);
    t48 = (~(t47));
    t49 = *((unsigned int *)t46);
    t50 = (t49 & t48);
    t51 = (t50 != 0);
    if (t51 > 0)
        goto LAB43;

LAB42:    t37 = (t0 + 7240);
    *((int *)t37) = 1;
    t38 = (t0 + 6656U);
    *((char **)t38) = &&LAB37;
    goto LAB1;

LAB40:    t35 = (t46 + 4);
    *((unsigned int *)t46) = 1;
    *((unsigned int *)t35) = 1;
    goto LAB41;

LAB43:    t39 = (t0 + 7240);
    *((int *)t39) = 0;
    xsi_set_current_line(48, ng34);
    t40 = (t0 + 7256);
    *((int *)t40) = 1;
    t42 = (t0 + 6688);
    *((char **)t42) = t40;
    *((char **)t1) = &&LAB44;
    goto LAB1;

LAB44:    xsi_set_current_line(49, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    t2 = (t0 + 3816);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t19 = (t0 + 6464);
    t20 = (t0 + 848);
    t26 = xsi_create_subprogram_invocation(t19, 0, t0, t20, 0, 0);
    t27 = (t26 + 96U);
    t28 = *((char **)t27);
    t29 = (t28 + 160U);
    xsi_vlogvar_assign_value(t29, t6, 0, 0, 4);

LAB45:    t30 = (t0 + 6560);
    t31 = *((char **)t30);
    t33 = (t31 + 80U);
    t34 = *((char **)t33);
    t35 = (t34 + 272U);
    t36 = *((char **)t35);
    t37 = (t36 + 0U);
    t38 = *((char **)t37);
    t41 = ((int  (*)(char *, char *))t38)(t0, t31);
    if (t41 != 0)
        goto LAB47;

LAB46:    t31 = (t0 + 6560);
    t39 = *((char **)t31);
    t31 = (t39 + 96U);
    t40 = *((char **)t31);
    t42 = (t40 + 0U);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    memcpy(t5, t44, 8);
    t45 = (t0 + 848);
    t52 = (t0 + 6464);
    t53 = 0;
    xsi_delete_subprogram_invocation(t45, t39, t0, t52, t53);
    memset(t46, 0, 8);
    t54 = (t3 + 4);
    t55 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t5);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t54);
    t11 = *((unsigned int *)t55);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t54);
    t15 = *((unsigned int *)t55);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB49;

LAB48:    if (t16 != 0)
        goto LAB50;

LAB51:    t57 = (t46 + 4);
    t21 = *((unsigned int *)t57);
    t22 = (~(t21));
    t23 = *((unsigned int *)t46);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB52;

LAB53:    xsi_set_current_line(51, ng34);

LAB58:    xsi_set_current_line(52, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t5, t3, 8);
    t2 = ((char*)((ng40)));
    t4 = (t0 + 6464);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t4, 0, t0, t6, 0, 0);
    t20 = (t0 + 5416);
    xsi_vlogvar_assign_value(t20, t5, 0, 0, 32);
    t26 = (t0 + 5576);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB59:    t27 = (t0 + 6560);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t33 = *((char **)t31);
    t34 = (t33 + 0U);
    t35 = *((char **)t34);
    t41 = ((int  (*)(char *, char *))t35)(t0, t28);
    if (t41 != 0)
        goto LAB61;

LAB60:    t28 = (t0 + 6560);
    t36 = *((char **)t28);
    t28 = (t0 + 5256);
    t37 = (t28 + 56U);
    t38 = *((char **)t37);
    memcpy(t46, t38, 8);
    t39 = (t0 + 2144);
    t40 = (t0 + 6464);
    t42 = 0;
    xsi_delete_subprogram_invocation(t39, t36, t0, t40, t42);
    t43 = (t0 + 3816);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    xsi_vlogfile_write(1, 0, 0, ng41, 3, t0, (char)118, t46, 1, (char)118, t45, 5);
    xsi_set_current_line(53, ng34);
    t2 = (t0 + 3656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t4, 5, t6, 32);
    t19 = (t0 + 3656);
    xsi_vlogvar_assign_value(t19, t5, 0, 0, 5);

LAB54:    xsi_set_current_line(47, ng34);
    t2 = (t0 + 3816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t4, 5, t6, 32);
    t19 = (t0 + 3816);
    xsi_vlogvar_assign_value(t19, t5, 0, 0, 5);
    goto LAB28;

LAB47:    t30 = (t0 + 6656U);
    *((char **)t30) = &&LAB45;
    goto LAB1;

LAB49:    *((unsigned int *)t46) = 1;
    goto LAB51;

LAB50:    t56 = (t46 + 4);
    *((unsigned int *)t46) = 1;
    *((unsigned int *)t56) = 1;
    goto LAB51;

LAB52:    xsi_set_current_line(50, ng34);
    t58 = (t0 + 2776U);
    t59 = *((char **)t58);
    memcpy(t60, t59, 8);
    t58 = ((char*)((ng40)));
    t61 = (t0 + 6464);
    t62 = (t0 + 2144);
    t63 = xsi_create_subprogram_invocation(t61, 0, t0, t62, 0, 0);
    t64 = (t0 + 5416);
    xsi_vlogvar_assign_value(t64, t60, 0, 0, 32);
    t65 = (t0 + 5576);
    xsi_vlogvar_assign_value(t65, t58, 0, 0, 6);

LAB55:    t66 = (t0 + 6560);
    t67 = *((char **)t66);
    t68 = (t67 + 80U);
    t69 = *((char **)t68);
    t70 = (t69 + 272U);
    t71 = *((char **)t70);
    t72 = (t71 + 0U);
    t73 = *((char **)t72);
    t74 = ((int  (*)(char *, char *))t73)(t0, t67);
    if (t74 != 0)
        goto LAB57;

LAB56:    t67 = (t0 + 6560);
    t75 = *((char **)t67);
    t67 = (t0 + 5256);
    t76 = (t67 + 56U);
    t77 = *((char **)t76);
    memcpy(t78, t77, 8);
    t79 = (t0 + 2144);
    t80 = (t0 + 6464);
    t81 = 0;
    xsi_delete_subprogram_invocation(t79, t75, t0, t80, t81);
    t82 = (t0 + 3816);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    xsi_vlogfile_write(1, 0, 0, ng39, 3, t0, (char)118, t78, 1, (char)118, t84, 5);
    goto LAB54;

LAB57:    t66 = (t0 + 6656U);
    *((char **)t66) = &&LAB55;
    goto LAB1;

LAB61:    t27 = (t0 + 6656U);
    *((char **)t27) = &&LAB59;
    goto LAB1;

LAB62:    xsi_set_current_line(58, ng34);
    t2 = (t0 + 2936U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng31)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB64;

LAB63:    if (t16 != 0)
        goto LAB65;

LAB66:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB67;

LAB68:    xsi_set_current_line(61, ng34);
    t2 = (t0 + 3656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t4, 5, t6, 32);
    t19 = (t0 + 3656);
    xsi_vlogvar_assign_value(t19, t5, 0, 0, 5);

LAB69:    xsi_set_current_line(63, ng34);
    t2 = (t0 + 6464);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB70;
    goto LAB1;

LAB64:    *((unsigned int *)t5) = 1;
    goto LAB66;

LAB65:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB66;

LAB67:    xsi_set_current_line(59, ng34);
    xsi_vlogfile_write(1, 0, 0, ng42, 1, t0);
    goto LAB69;

LAB70:    xsi_set_current_line(64, ng34);
    t3 = ((char*)((ng31)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(65, ng34);
    t2 = (t0 + 6464);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB71;
    goto LAB1;

LAB71:    xsi_set_current_line(67, ng34);
    t3 = (t0 + 2936U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t6 = (t4 + 4);
    t19 = (t3 + 4);
    t7 = *((unsigned int *)t4);
    t8 = *((unsigned int *)t3);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t6);
    t11 = *((unsigned int *)t19);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t19);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB73;

LAB72:    if (t16 != 0)
        goto LAB74;

LAB75:    t26 = (t5 + 4);
    t21 = *((unsigned int *)t26);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB76;

LAB77:    xsi_set_current_line(70, ng34);
    t2 = (t0 + 3656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t4, 5, t6, 32);
    t19 = (t0 + 3656);
    xsi_vlogvar_assign_value(t19, t5, 0, 0, 5);

LAB78:    xsi_set_current_line(72, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3336);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(74, ng34);
    t2 = (t0 + 3656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng36)));
    t19 = ((char*)((ng37)));
    t20 = (t0 + 6464);
    t26 = (t0 + 1280);
    t27 = xsi_create_subprogram_invocation(t20, 0, t0, t26, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t26, t27);
    t28 = (t0 + 4136);
    xsi_vlogvar_assign_value(t28, t5, 0, 0, 8);
    t29 = (t0 + 4296);
    xsi_vlogvar_assign_value(t29, t6, 0, 0, 8);
    t30 = (t0 + 4456);
    t31 = ((char*)((ng37)));
    t32 = xsi_vlog_convert_to_real(t31, 32, 1);
    xsi_vlogvar_assign_value_double(t30, t32, 0);

LAB81:    t33 = (t0 + 6560);
    t34 = *((char **)t33);
    t35 = (t34 + 80U);
    t36 = *((char **)t35);
    t37 = (t36 + 272U);
    t38 = *((char **)t37);
    t39 = (t38 + 0U);
    t40 = *((char **)t39);
    t41 = ((int  (*)(char *, char *))t40)(t0, t34);

LAB83:    if (t41 != 0)
        goto LAB84;

LAB79:    t34 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t34);

LAB80:    t42 = (t0 + 6560);
    t43 = *((char **)t42);
    t42 = (t0 + 1280);
    t44 = (t0 + 6464);
    t45 = 0;
    xsi_delete_subprogram_invocation(t42, t43, t0, t44, t45);
    goto LAB1;

LAB73:    *((unsigned int *)t5) = 1;
    goto LAB75;

LAB74:    t20 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB75;

LAB76:    xsi_set_current_line(68, ng34);
    xsi_vlogfile_write(1, 0, 0, ng43, 1, t0);
    goto LAB78;

LAB82:;
LAB84:    t33 = (t0 + 6656U);
    *((char **)t33) = &&LAB81;
    goto LAB1;

}

static void Always_77_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 6904U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(78, ng34);
    t2 = (t0 + 6712);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(78, ng34);
    t4 = (t0 + 3496);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t0 + 3496);
    xsi_vlogvar_assign_value(t14, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

}


extern void work_m_00000000001227686424_1373006524_init()
{
	static char *pe[] = {(void *)Initial_27_0,(void *)Always_77_1};
	static char *se[] = {(void *)sp_exp_output,(void *)sp_succ_exit,(void *)sp_err_exit,(void *)sp_show_LEDs};
	xsi_register_didat("work_m_00000000001227686424_1373006524", "isim/test_ex2_isim_beh.exe.sim/work/m_00000000001227686424_1373006524.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
	xsi_register_subprogram_init(1, (void *)exp_output_varinit);
}
