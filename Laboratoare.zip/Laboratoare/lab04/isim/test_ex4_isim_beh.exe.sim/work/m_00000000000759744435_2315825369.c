/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/student/Desktop/lab/lab04_skel_remote/lab04_skel/ex4.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Cont_33_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 5720U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 2000U);
    t3 = *((char **)t2);
    t2 = (t0 + 7176);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 7032);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Cont_34_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 5968U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 2160U);
    t3 = *((char **)t2);
    t2 = (t0 + 7240);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 7048);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Cont_35_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 6216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 2320U);
    t3 = *((char **)t2);
    t2 = (t0 + 7304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 7064);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Cont_36_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 6464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 2480U);
    t3 = *((char **)t2);
    t2 = (t0 + 7368);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 7080);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Always_38_4(char *t0)
{
    char t14[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    int t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 6712U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 7096);
    *((int *)t2) = 1;
    t3 = (t0 + 6744);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(38, ng0);

LAB5:    xsi_set_current_line(39, ng0);
    t4 = (t0 + 2640U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(48, ng0);

LAB10:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 4160);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB11:    t5 = (t0 + 472);
    t11 = *((char **)t5);
    t13 = xsi_vlog_unsigned_case_compare(t4, 3, t11, 32);
    if (t13 == 1)
        goto LAB12;

LAB13:    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t13 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t13 == 1)
        goto LAB14;

LAB15:    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t13 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t13 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 880);
    t3 = *((char **)t2);
    t13 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t13 == 1)
        goto LAB18;

LAB19:    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t13 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t13 == 1)
        goto LAB20;

LAB21:
LAB22:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(39, ng0);

LAB9:    xsi_set_current_line(40, ng0);
    t11 = (t0 + 472);
    t12 = *((char **)t11);
    t11 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t11, t12, 0, 0, 3, 0LL);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4000);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(44, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(46, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(47, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB8;

LAB12:    xsi_set_current_line(53, ng0);

LAB23:    xsi_set_current_line(54, ng0);
    t5 = (t0 + 2960U);
    t12 = *((char **)t5);
    t5 = (t12 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (~(t6));
    t8 = *((unsigned int *)t12);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB24;

LAB25:    xsi_set_current_line(59, ng0);

LAB36:    xsi_set_current_line(60, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB26:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3440U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB37;

LAB38:    xsi_set_current_line(68, ng0);

LAB49:    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB39:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 3280U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(77, ng0);

LAB62:    xsi_set_current_line(78, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB52:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 3120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB63;

LAB64:    xsi_set_current_line(86, ng0);

LAB75:    xsi_set_current_line(87, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB65:    goto LAB22;

LAB14:    xsi_set_current_line(93, ng0);

LAB76:    xsi_set_current_line(94, ng0);
    t2 = (t0 + 2960U);
    t5 = *((char **)t2);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB77;

LAB78:    xsi_set_current_line(99, ng0);

LAB89:    xsi_set_current_line(100, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB79:    xsi_set_current_line(103, ng0);
    t2 = (t0 + 3440U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB90;

LAB91:    xsi_set_current_line(108, ng0);

LAB102:    xsi_set_current_line(109, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB92:    xsi_set_current_line(112, ng0);
    t2 = (t0 + 3280U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB103;

LAB104:    xsi_set_current_line(117, ng0);

LAB115:    xsi_set_current_line(118, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB105:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 3120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB116;

LAB117:    xsi_set_current_line(126, ng0);

LAB128:    xsi_set_current_line(127, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB118:    goto LAB22;

LAB16:    xsi_set_current_line(133, ng0);

LAB129:    xsi_set_current_line(134, ng0);
    t2 = (t0 + 2960U);
    t5 = *((char **)t2);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB130;

LAB131:    xsi_set_current_line(139, ng0);

LAB142:    xsi_set_current_line(140, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB132:    xsi_set_current_line(143, ng0);
    t2 = (t0 + 3440U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB143;

LAB144:    xsi_set_current_line(148, ng0);

LAB155:    xsi_set_current_line(149, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB145:    xsi_set_current_line(152, ng0);
    t2 = (t0 + 3280U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB156;

LAB157:    xsi_set_current_line(157, ng0);

LAB168:    xsi_set_current_line(158, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB158:    xsi_set_current_line(161, ng0);
    t2 = (t0 + 3120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB169;

LAB170:    xsi_set_current_line(166, ng0);

LAB181:    xsi_set_current_line(167, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB171:    goto LAB22;

LAB18:    xsi_set_current_line(173, ng0);

LAB182:    xsi_set_current_line(174, ng0);
    t2 = (t0 + 2960U);
    t5 = *((char **)t2);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB183;

LAB184:    xsi_set_current_line(179, ng0);

LAB195:    xsi_set_current_line(180, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB185:    xsi_set_current_line(183, ng0);
    t2 = (t0 + 3440U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB196;

LAB197:    xsi_set_current_line(188, ng0);

LAB208:    xsi_set_current_line(189, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB198:    xsi_set_current_line(192, ng0);
    t2 = (t0 + 3280U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB209;

LAB210:    xsi_set_current_line(197, ng0);

LAB221:    xsi_set_current_line(198, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB211:    xsi_set_current_line(201, ng0);
    t2 = (t0 + 3120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB222;

LAB223:    xsi_set_current_line(206, ng0);

LAB234:    xsi_set_current_line(207, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB224:    goto LAB22;

LAB20:    xsi_set_current_line(212, ng0);

LAB235:    xsi_set_current_line(213, ng0);
    t2 = (t0 + 2960U);
    t5 = *((char **)t2);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB236;

LAB237:    xsi_set_current_line(218, ng0);

LAB248:    xsi_set_current_line(219, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB238:    xsi_set_current_line(222, ng0);
    t2 = (t0 + 3440U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB249;

LAB250:    xsi_set_current_line(227, ng0);

LAB261:    xsi_set_current_line(228, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB251:    xsi_set_current_line(231, ng0);
    t2 = (t0 + 3280U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB262;

LAB263:    xsi_set_current_line(236, ng0);

LAB274:    xsi_set_current_line(237, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB264:    xsi_set_current_line(240, ng0);
    t2 = (t0 + 3120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB275;

LAB276:    xsi_set_current_line(245, ng0);

LAB287:    xsi_set_current_line(246, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB277:    goto LAB22;

LAB24:    xsi_set_current_line(54, ng0);

LAB27:    xsi_set_current_line(55, ng0);
    t15 = (t0 + 4320);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memset(t14, 0, 8);
    t18 = (t17 + 4);
    t19 = *((unsigned int *)t18);
    t20 = (~(t19));
    t21 = *((unsigned int *)t17);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB31;

LAB29:    if (*((unsigned int *)t18) == 0)
        goto LAB28;

LAB30:    t24 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t24) = 1;

LAB31:    t25 = (t14 + 4);
    t26 = *((unsigned int *)t25);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB32;

LAB33:
LAB34:    goto LAB26;

LAB28:    *((unsigned int *)t14) = 1;
    goto LAB31;

LAB32:    xsi_set_current_line(55, ng0);

LAB35:    xsi_set_current_line(56, ng0);
    t31 = ((char*)((ng2)));
    t32 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t32, t31, 0, 0, 1, 0LL);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB34;

LAB37:    xsi_set_current_line(63, ng0);

LAB40:    xsi_set_current_line(64, ng0);
    t5 = (t0 + 4640);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB44;

LAB42:    if (*((unsigned int *)t15) == 0)
        goto LAB41;

LAB43:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB44:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB45;

LAB46:
LAB47:    goto LAB39;

LAB41:    *((unsigned int *)t14) = 1;
    goto LAB44;

LAB45:    xsi_set_current_line(64, ng0);

LAB48:    xsi_set_current_line(65, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB47;

LAB50:    xsi_set_current_line(72, ng0);

LAB53:    xsi_set_current_line(73, ng0);
    t5 = (t0 + 4800);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB57;

LAB55:    if (*((unsigned int *)t15) == 0)
        goto LAB54;

LAB56:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB57:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB58;

LAB59:
LAB60:    goto LAB52;

LAB54:    *((unsigned int *)t14) = 1;
    goto LAB57;

LAB58:    xsi_set_current_line(73, ng0);

LAB61:    xsi_set_current_line(74, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB60;

LAB63:    xsi_set_current_line(81, ng0);

LAB66:    xsi_set_current_line(82, ng0);
    t5 = (t0 + 4480);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB70;

LAB68:    if (*((unsigned int *)t15) == 0)
        goto LAB67;

LAB69:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB70:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB71;

LAB72:
LAB73:    goto LAB65;

LAB67:    *((unsigned int *)t14) = 1;
    goto LAB70;

LAB71:    xsi_set_current_line(82, ng0);

LAB74:    xsi_set_current_line(83, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB73;

LAB77:    xsi_set_current_line(94, ng0);

LAB80:    xsi_set_current_line(95, ng0);
    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t15 = *((char **)t12);
    memset(t14, 0, 8);
    t16 = (t15 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (~(t19));
    t21 = *((unsigned int *)t15);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB84;

LAB82:    if (*((unsigned int *)t16) == 0)
        goto LAB81;

LAB83:    t17 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t17) = 1;

LAB84:    t18 = (t14 + 4);
    t26 = *((unsigned int *)t18);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB85;

LAB86:
LAB87:    goto LAB79;

LAB81:    *((unsigned int *)t14) = 1;
    goto LAB84;

LAB85:    xsi_set_current_line(95, ng0);

LAB88:    xsi_set_current_line(96, ng0);
    t24 = ((char*)((ng2)));
    t25 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t25, t24, 0, 0, 1, 0LL);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB87;

LAB90:    xsi_set_current_line(103, ng0);

LAB93:    xsi_set_current_line(104, ng0);
    t5 = (t0 + 4640);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB97;

LAB95:    if (*((unsigned int *)t15) == 0)
        goto LAB94;

LAB96:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB97:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB98;

LAB99:
LAB100:    goto LAB92;

LAB94:    *((unsigned int *)t14) = 1;
    goto LAB97;

LAB98:    xsi_set_current_line(104, ng0);

LAB101:    xsi_set_current_line(105, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(106, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB100;

LAB103:    xsi_set_current_line(112, ng0);

LAB106:    xsi_set_current_line(113, ng0);
    t5 = (t0 + 4800);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB110;

LAB108:    if (*((unsigned int *)t15) == 0)
        goto LAB107;

LAB109:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB110:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB111;

LAB112:
LAB113:    goto LAB105;

LAB107:    *((unsigned int *)t14) = 1;
    goto LAB110;

LAB111:    xsi_set_current_line(113, ng0);

LAB114:    xsi_set_current_line(114, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(115, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB113;

LAB116:    xsi_set_current_line(121, ng0);

LAB119:    xsi_set_current_line(122, ng0);
    t5 = (t0 + 4480);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB123;

LAB121:    if (*((unsigned int *)t15) == 0)
        goto LAB120;

LAB122:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB123:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB124;

LAB125:
LAB126:    goto LAB118;

LAB120:    *((unsigned int *)t14) = 1;
    goto LAB123;

LAB124:    xsi_set_current_line(122, ng0);

LAB127:    xsi_set_current_line(123, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB126;

LAB130:    xsi_set_current_line(134, ng0);

LAB133:    xsi_set_current_line(135, ng0);
    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t15 = *((char **)t12);
    memset(t14, 0, 8);
    t16 = (t15 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (~(t19));
    t21 = *((unsigned int *)t15);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB137;

LAB135:    if (*((unsigned int *)t16) == 0)
        goto LAB134;

LAB136:    t17 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t17) = 1;

LAB137:    t18 = (t14 + 4);
    t26 = *((unsigned int *)t18);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB138;

LAB139:
LAB140:    goto LAB132;

LAB134:    *((unsigned int *)t14) = 1;
    goto LAB137;

LAB138:    xsi_set_current_line(135, ng0);

LAB141:    xsi_set_current_line(136, ng0);
    t24 = ((char*)((ng2)));
    t25 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t25, t24, 0, 0, 1, 0LL);
    xsi_set_current_line(137, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB140;

LAB143:    xsi_set_current_line(143, ng0);

LAB146:    xsi_set_current_line(144, ng0);
    t5 = (t0 + 4640);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB150;

LAB148:    if (*((unsigned int *)t15) == 0)
        goto LAB147;

LAB149:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB150:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB151;

LAB152:
LAB153:    goto LAB145;

LAB147:    *((unsigned int *)t14) = 1;
    goto LAB150;

LAB151:    xsi_set_current_line(144, ng0);

LAB154:    xsi_set_current_line(145, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB153;

LAB156:    xsi_set_current_line(152, ng0);

LAB159:    xsi_set_current_line(153, ng0);
    t5 = (t0 + 4800);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB163;

LAB161:    if (*((unsigned int *)t15) == 0)
        goto LAB160;

LAB162:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB163:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB164;

LAB165:
LAB166:    goto LAB158;

LAB160:    *((unsigned int *)t14) = 1;
    goto LAB163;

LAB164:    xsi_set_current_line(153, ng0);

LAB167:    xsi_set_current_line(154, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 880);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB166;

LAB169:    xsi_set_current_line(161, ng0);

LAB172:    xsi_set_current_line(162, ng0);
    t5 = (t0 + 4480);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB176;

LAB174:    if (*((unsigned int *)t15) == 0)
        goto LAB173;

LAB175:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB176:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB177;

LAB178:
LAB179:    goto LAB171;

LAB173:    *((unsigned int *)t14) = 1;
    goto LAB176;

LAB177:    xsi_set_current_line(162, ng0);

LAB180:    xsi_set_current_line(163, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(164, ng0);
    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB179;

LAB183:    xsi_set_current_line(174, ng0);

LAB186:    xsi_set_current_line(175, ng0);
    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t15 = *((char **)t12);
    memset(t14, 0, 8);
    t16 = (t15 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (~(t19));
    t21 = *((unsigned int *)t15);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB190;

LAB188:    if (*((unsigned int *)t16) == 0)
        goto LAB187;

LAB189:    t17 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t17) = 1;

LAB190:    t18 = (t14 + 4);
    t26 = *((unsigned int *)t18);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB191;

LAB192:
LAB193:    goto LAB185;

LAB187:    *((unsigned int *)t14) = 1;
    goto LAB190;

LAB191:    xsi_set_current_line(175, ng0);

LAB194:    xsi_set_current_line(176, ng0);
    t24 = ((char*)((ng2)));
    t25 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t25, t24, 0, 0, 1, 0LL);
    xsi_set_current_line(177, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB193;

LAB196:    xsi_set_current_line(183, ng0);

LAB199:    xsi_set_current_line(184, ng0);
    t5 = (t0 + 4640);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB203;

LAB201:    if (*((unsigned int *)t15) == 0)
        goto LAB200;

LAB202:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB203:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB204;

LAB205:
LAB206:    goto LAB198;

LAB200:    *((unsigned int *)t14) = 1;
    goto LAB203;

LAB204:    xsi_set_current_line(184, ng0);

LAB207:    xsi_set_current_line(185, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(186, ng0);
    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB206;

LAB209:    xsi_set_current_line(192, ng0);

LAB212:    xsi_set_current_line(193, ng0);
    t5 = (t0 + 4800);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB216;

LAB214:    if (*((unsigned int *)t15) == 0)
        goto LAB213;

LAB215:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB216:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB217;

LAB218:
LAB219:    goto LAB211;

LAB213:    *((unsigned int *)t14) = 1;
    goto LAB216;

LAB217:    xsi_set_current_line(193, ng0);

LAB220:    xsi_set_current_line(194, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(195, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB219;

LAB222:    xsi_set_current_line(201, ng0);

LAB225:    xsi_set_current_line(202, ng0);
    t5 = (t0 + 4480);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB229;

LAB227:    if (*((unsigned int *)t15) == 0)
        goto LAB226;

LAB228:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB229:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB230;

LAB231:
LAB232:    goto LAB224;

LAB226:    *((unsigned int *)t14) = 1;
    goto LAB229;

LAB230:    xsi_set_current_line(202, ng0);

LAB233:    xsi_set_current_line(203, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(204, ng0);
    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB232;

LAB236:    xsi_set_current_line(213, ng0);

LAB239:    xsi_set_current_line(214, ng0);
    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t15 = *((char **)t12);
    memset(t14, 0, 8);
    t16 = (t15 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (~(t19));
    t21 = *((unsigned int *)t15);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB243;

LAB241:    if (*((unsigned int *)t16) == 0)
        goto LAB240;

LAB242:    t17 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t17) = 1;

LAB243:    t18 = (t14 + 4);
    t26 = *((unsigned int *)t18);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB244;

LAB245:
LAB246:    goto LAB238;

LAB240:    *((unsigned int *)t14) = 1;
    goto LAB243;

LAB244:    xsi_set_current_line(214, ng0);

LAB247:    xsi_set_current_line(215, ng0);
    t24 = ((char*)((ng2)));
    t25 = (t0 + 4320);
    xsi_vlogvar_wait_assign_value(t25, t24, 0, 0, 1, 0LL);
    xsi_set_current_line(216, ng0);
    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB246;

LAB249:    xsi_set_current_line(222, ng0);

LAB252:    xsi_set_current_line(223, ng0);
    t5 = (t0 + 4640);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB256;

LAB254:    if (*((unsigned int *)t15) == 0)
        goto LAB253;

LAB255:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB256:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB257;

LAB258:
LAB259:    goto LAB251;

LAB253:    *((unsigned int *)t14) = 1;
    goto LAB256;

LAB257:    xsi_set_current_line(223, ng0);

LAB260:    xsi_set_current_line(224, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4640);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(225, ng0);
    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB259;

LAB262:    xsi_set_current_line(231, ng0);

LAB265:    xsi_set_current_line(232, ng0);
    t5 = (t0 + 4800);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB269;

LAB267:    if (*((unsigned int *)t15) == 0)
        goto LAB266;

LAB268:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB269:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB270;

LAB271:
LAB272:    goto LAB264;

LAB266:    *((unsigned int *)t14) = 1;
    goto LAB269;

LAB270:    xsi_set_current_line(232, ng0);

LAB273:    xsi_set_current_line(233, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4800);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(234, ng0);
    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB272;

LAB275:    xsi_set_current_line(240, ng0);

LAB278:    xsi_set_current_line(241, ng0);
    t5 = (t0 + 4480);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t15 = (t12 + 4);
    t19 = *((unsigned int *)t15);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t21 & t20);
    t23 = (t22 & 1U);
    if (t23 != 0)
        goto LAB282;

LAB280:    if (*((unsigned int *)t15) == 0)
        goto LAB279;

LAB281:    t16 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t16) = 1;

LAB282:    t17 = (t14 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB283;

LAB284:
LAB285:    goto LAB277;

LAB279:    *((unsigned int *)t14) = 1;
    goto LAB282;

LAB283:    xsi_set_current_line(241, ng0);

LAB286:    xsi_set_current_line(242, ng0);
    t18 = ((char*)((ng2)));
    t24 = (t0 + 4480);
    xsi_vlogvar_wait_assign_value(t24, t18, 0, 0, 1, 0LL);
    xsi_set_current_line(243, ng0);
    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t2 = (t0 + 4160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    goto LAB285;

}


extern void work_m_00000000000759744435_2315825369_init()
{
	static char *pe[] = {(void *)Cont_33_0,(void *)Cont_34_1,(void *)Cont_35_2,(void *)Cont_36_3,(void *)Always_38_4};
	xsi_register_didat("work_m_00000000000759744435_2315825369", "isim/test_ex4_isim_beh.exe.sim/work/m_00000000000759744435_2315825369.didat");
	xsi_register_executes(pe);
}
