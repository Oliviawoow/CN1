/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "state";
static const char *ng1 = "exp_output";
static const char *ng2 = "C:/Users/student/Desktop/lab/lab04_skel_remote/lab04_skel/lib/helpers.vh";
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {170U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {85U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {4U, 0U};
static unsigned int ng9[] = {5U, 0U};
static unsigned int ng10[] = {129U, 0U};
static unsigned int ng11[] = {6U, 0U};
static unsigned int ng12[] = {66U, 0U};
static unsigned int ng13[] = {7U, 0U};
static unsigned int ng14[] = {36U, 0U};
static unsigned int ng15[] = {8U, 0U};
static unsigned int ng16[] = {24U, 0U};
static unsigned int ng17[] = {9U, 0U};
static unsigned int ng18[] = {10U, 0U};
static unsigned int ng19[] = {11U, 0U};
static unsigned int ng20[] = {12U, 0U};
static unsigned int ng21[] = {105U, 0U};
static unsigned int ng22[] = {13U, 0U};
static unsigned int ng23[] = {141U, 0U};
static unsigned int ng24[] = {14U, 0U};
static unsigned int ng25[] = {139U, 0U};
static unsigned int ng26[] = {15U, 0U};
static unsigned int ng27[] = {255U, 255U};
static const char *ng28 = "Total: %0d/%0d (%1.1Fp)";
static const char *ng29 = "The simulation is canceling...";
static int ng30[] = {0, 0};
static int ng31[] = {1, 0};
static const char *ng32 = "* ";
static const char *ng33 = "_ ";
static const char *ng34 = "C:/Users/student/Desktop/lab/lab04_skel_remote/lab04_skel/test_ex1.v";
static const char *ng35 = "LED: ";
static const char *ng36 = "- FAILED";
static const char *ng37 = "Check LED initial state!";
static const char *ng38 = "- PASSED";
static const char *ng39 = "Check LED on state!";
static const char *ng40 = "Check LED off state!";



static void exp_output_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 160U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 3, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng1, 2, 7, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static int sp_exp_output(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    t0 = 1;
    xsi_set_current_line(3, ng2);

LAB2:    xsi_set_current_line(4, ng2);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 160U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);

LAB3:    t8 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 4);
    if (t9 == 1)
        goto LAB4;

LAB5:    t3 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB6;

LAB7:    t3 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB8;

LAB9:    t3 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB10;

LAB11:    t3 = ((char*)((ng9)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB12;

LAB13:    t3 = ((char*)((ng11)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB14;

LAB15:    t3 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB16;

LAB17:    t3 = ((char*)((ng15)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB18;

LAB19:    t3 = ((char*)((ng17)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB20;

LAB21:    t3 = ((char*)((ng18)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB22;

LAB23:    t3 = ((char*)((ng19)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB24;

LAB25:    t3 = ((char*)((ng20)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB26;

LAB27:    t3 = ((char*)((ng22)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB28;

LAB29:    t3 = ((char*)((ng24)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB30;

LAB31:    t3 = ((char*)((ng26)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB32;

LAB33:
LAB35:
LAB34:    xsi_set_current_line(20, ng2);
    t3 = ((char*)((ng27)));
    t4 = (t2 + 96U);
    t5 = *((char **)t4);
    t6 = (t5 + 0U);
    xsi_vlogvar_assign_value(t6, t3, 0, 0, 8);

LAB36:    t0 = 0;

LAB1:    return t0;
LAB4:    xsi_set_current_line(5, ng2);
    t10 = ((char*)((ng4)));
    t11 = (t2 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 0U);
    xsi_vlogvar_assign_value(t13, t10, 0, 0, 8);
    goto LAB36;

LAB6:    xsi_set_current_line(6, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB8:    xsi_set_current_line(7, ng2);
    t4 = ((char*)((ng4)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB10:    xsi_set_current_line(8, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB12:    xsi_set_current_line(9, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB14:    xsi_set_current_line(10, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB16:    xsi_set_current_line(11, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB18:    xsi_set_current_line(12, ng2);
    t4 = ((char*)((ng16)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB20:    xsi_set_current_line(13, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB22:    xsi_set_current_line(14, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB24:    xsi_set_current_line(15, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB26:    xsi_set_current_line(16, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB28:    xsi_set_current_line(17, ng2);
    t4 = ((char*)((ng23)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB30:    xsi_set_current_line(18, ng2);
    t4 = ((char*)((ng25)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB32:    xsi_set_current_line(19, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

}

static int sp_succ_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(29, ng2);

LAB2:    xsi_set_current_line(30, ng2);
    t3 = (t1 + 3976);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4136);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 3976);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 4296);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 4136);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1280);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(31, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_err_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(39, ng2);

LAB2:    xsi_set_current_line(40, ng2);
    t3 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng29, 1, t3);
    xsi_set_current_line(41, ng2);
    t3 = (t1 + 4616);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4776);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 4616);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 4936);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 4776);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(42, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_show_LEDs(char *t1, char *t2)
{
    char t7[8];
    char t20[8];
    char t28[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t0 = 1;
    xsi_set_current_line(50, ng2);

LAB2:    xsi_set_current_line(51, ng2);
    xsi_set_current_line(51, ng2);
    t3 = (t1 + 5416);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 5576);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 6);

LAB3:    t3 = (t1 + 5576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng30)));
    memset(t7, 0, 8);
    t8 = (t5 + 4);
    if (*((unsigned int *)t8) != 0)
        goto LAB5;

LAB4:    t9 = (t6 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB5;

LAB8:    if (*((unsigned int *)t5) > *((unsigned int *)t6))
        goto LAB6;

LAB7:    t11 = (t7 + 4);
    t12 = *((unsigned int *)t11);
    t13 = (~(t12));
    t14 = *((unsigned int *)t7);
    t15 = (t14 & t13);
    t16 = (t15 != 0);
    if (t16 > 0)
        goto LAB9;

LAB10:    t0 = 0;

LAB1:    return t0;
LAB5:    t10 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB9:    xsi_set_current_line(51, ng2);

LAB11:    xsi_set_current_line(52, ng2);
    t17 = (t1 + 5256);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t21 = (t1 + 5256);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t1 + 5576);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = ((char*)((ng31)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_minus(t28, 32, t26, 6, t27, 32);
    xsi_vlog_generic_get_index_select_value(t20, 1, t19, t23, 2, t28, 32, 2);
    t29 = (t20 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (~(t30));
    t32 = *((unsigned int *)t20);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(55, ng2);
    t3 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng33, 1, t3);

LAB14:    xsi_set_current_line(51, ng2);
    t3 = (t1 + 5576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng31)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_minus(t7, 32, t5, 6, t6, 32);
    t8 = (t1 + 5576);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 6);
    goto LAB3;

LAB12:    xsi_set_current_line(53, ng2);
    t35 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng32, 1, t35);
    goto LAB14;

}

static void Initial_26_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    int t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;

LAB0:    t1 = (t0 + 6496U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(26, ng34);

LAB4:    xsi_set_current_line(28, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(29, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3336);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(32, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);
    xsi_set_current_line(35, ng34);
    t2 = (t0 + 6304);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(36, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(38, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng30)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB7;

LAB6:    if (t16 != 0)
        goto LAB8;

LAB9:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(42, ng34);

LAB26:    xsi_set_current_line(43, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(43, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB29:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB31:    if (t35 != 0)
        goto LAB32;

LAB27:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB28:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(43, ng34);
    xsi_vlogfile_write(1, 0, 0, ng38, 1, t0);
    xsi_set_current_line(44, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 32, t5, 5, t6, 32);
    t19 = (t0 + 3496);
    xsi_vlogvar_assign_value(t19, t4, 0, 0, 5);

LAB12:    xsi_set_current_line(47, ng34);
    t2 = (t0 + 6304);
    xsi_process_wait(t2, 22000LL);
    *((char **)t1) = &&LAB33;
    goto LAB1;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB8:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(38, ng34);

LAB13:    xsi_set_current_line(39, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(39, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB16:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB18:    if (t35 != 0)
        goto LAB19;

LAB14:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB15:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(39, ng34);
    xsi_vlogfile_write(1, 0, 0, ng36, 1, t0);
    xsi_set_current_line(40, ng34);
    xsi_vlogfile_write(1, 0, 0, ng37, 1, t0);
    xsi_set_current_line(41, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memcpy(t4, t5, 8);
    t6 = ((char*)((ng7)));
    t19 = (t0 + 6304);
    t20 = (t0 + 1712);
    t26 = xsi_create_subprogram_invocation(t19, 0, t0, t20, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t20, t26);
    t27 = (t0 + 4616);
    xsi_vlogvar_assign_value(t27, t4, 0, 0, 8);
    t28 = (t0 + 4776);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 8);
    t29 = (t0 + 4936);
    xsi_vlogvar_assign_value_double(t29, 1.5000000000000000, 0);

LAB22:    t30 = (t0 + 6400);
    t31 = *((char **)t30);
    t32 = (t31 + 80U);
    t33 = *((char **)t32);
    t34 = (t33 + 272U);
    t36 = *((char **)t34);
    t37 = (t36 + 0U);
    t38 = *((char **)t37);
    t35 = ((int  (*)(char *, char *))t38)(t0, t31);

LAB24:    if (t35 != 0)
        goto LAB25;

LAB20:    t31 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t31);

LAB21:    t39 = (t0 + 6400);
    t40 = *((char **)t39);
    t39 = (t0 + 1712);
    t41 = (t0 + 6304);
    t42 = 0;
    xsi_delete_subprogram_invocation(t39, t40, t0, t41, t42);
    goto LAB12;

LAB17:;
LAB19:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB16;
    goto LAB1;

LAB23:;
LAB25:    t30 = (t0 + 6496U);
    *((char **)t30) = &&LAB22;
    goto LAB1;

LAB30:;
LAB32:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB29;
    goto LAB1;

LAB33:    xsi_set_current_line(48, ng34);
    t3 = (t0 + 2776U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng31)));
    memset(t4, 0, 8);
    t6 = (t5 + 4);
    t19 = (t3 + 4);
    t7 = *((unsigned int *)t5);
    t8 = *((unsigned int *)t3);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t6);
    t11 = *((unsigned int *)t19);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t19);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB35;

LAB34:    if (t16 != 0)
        goto LAB36;

LAB37:    t26 = (t4 + 4);
    t21 = *((unsigned int *)t26);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB38;

LAB39:    xsi_set_current_line(52, ng34);

LAB54:    xsi_set_current_line(53, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(53, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB57:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB59:    if (t35 != 0)
        goto LAB60;

LAB55:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB56:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(53, ng34);
    xsi_vlogfile_write(1, 0, 0, ng38, 1, t0);
    xsi_set_current_line(54, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 32, t5, 5, t6, 32);
    t19 = (t0 + 3496);
    xsi_vlogvar_assign_value(t19, t4, 0, 0, 5);

LAB40:    xsi_set_current_line(57, ng34);
    t2 = (t0 + 6304);
    xsi_process_wait(t2, 22000LL);
    *((char **)t1) = &&LAB61;
    goto LAB1;

LAB35:    *((unsigned int *)t4) = 1;
    goto LAB37;

LAB36:    t20 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB37;

LAB38:    xsi_set_current_line(48, ng34);

LAB41:    xsi_set_current_line(49, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(49, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB44:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB46:    if (t35 != 0)
        goto LAB47;

LAB42:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB43:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(49, ng34);
    xsi_vlogfile_write(1, 0, 0, ng36, 1, t0);
    xsi_set_current_line(50, ng34);
    xsi_vlogfile_write(1, 0, 0, ng39, 1, t0);
    xsi_set_current_line(51, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memcpy(t4, t5, 8);
    t6 = ((char*)((ng7)));
    t19 = (t0 + 6304);
    t20 = (t0 + 1712);
    t26 = xsi_create_subprogram_invocation(t19, 0, t0, t20, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t20, t26);
    t27 = (t0 + 4616);
    xsi_vlogvar_assign_value(t27, t4, 0, 0, 8);
    t28 = (t0 + 4776);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 8);
    t29 = (t0 + 4936);
    xsi_vlogvar_assign_value_double(t29, 1.5000000000000000, 0);

LAB50:    t30 = (t0 + 6400);
    t31 = *((char **)t30);
    t32 = (t31 + 80U);
    t33 = *((char **)t32);
    t34 = (t33 + 272U);
    t36 = *((char **)t34);
    t37 = (t36 + 0U);
    t38 = *((char **)t37);
    t35 = ((int  (*)(char *, char *))t38)(t0, t31);

LAB52:    if (t35 != 0)
        goto LAB53;

LAB48:    t31 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t31);

LAB49:    t39 = (t0 + 6400);
    t40 = *((char **)t39);
    t39 = (t0 + 1712);
    t41 = (t0 + 6304);
    t42 = 0;
    xsi_delete_subprogram_invocation(t39, t40, t0, t41, t42);
    goto LAB40;

LAB45:;
LAB47:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB44;
    goto LAB1;

LAB51:;
LAB53:    t30 = (t0 + 6496U);
    *((char **)t30) = &&LAB50;
    goto LAB1;

LAB58:;
LAB60:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB57;
    goto LAB1;

LAB61:    xsi_set_current_line(58, ng34);
    t3 = (t0 + 2776U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t4, 0, 8);
    t6 = (t5 + 4);
    t19 = (t3 + 4);
    t7 = *((unsigned int *)t5);
    t8 = *((unsigned int *)t3);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t6);
    t11 = *((unsigned int *)t19);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t19);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB63;

LAB62:    if (t16 != 0)
        goto LAB64;

LAB65:    t26 = (t4 + 4);
    t21 = *((unsigned int *)t26);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB66;

LAB67:    xsi_set_current_line(62, ng34);

LAB82:    xsi_set_current_line(63, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(63, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB85:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB87:    if (t35 != 0)
        goto LAB88;

LAB83:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB84:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(63, ng34);
    xsi_vlogfile_write(1, 0, 0, ng38, 1, t0);
    xsi_set_current_line(64, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng31)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 32, t5, 5, t6, 32);
    t19 = (t0 + 3496);
    xsi_vlogvar_assign_value(t19, t4, 0, 0, 5);

LAB68:    xsi_set_current_line(67, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memcpy(t4, t5, 8);
    t6 = ((char*)((ng7)));
    t19 = (t0 + 6304);
    t20 = (t0 + 1280);
    t26 = xsi_create_subprogram_invocation(t19, 0, t0, t20, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t20, t26);
    t27 = (t0 + 3976);
    xsi_vlogvar_assign_value(t27, t4, 0, 0, 8);
    t28 = (t0 + 4136);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 8);
    t29 = (t0 + 4296);
    xsi_vlogvar_assign_value_double(t29, 1.5000000000000000, 0);

LAB91:    t30 = (t0 + 6400);
    t31 = *((char **)t30);
    t32 = (t31 + 80U);
    t33 = *((char **)t32);
    t34 = (t33 + 272U);
    t36 = *((char **)t34);
    t37 = (t36 + 0U);
    t38 = *((char **)t37);
    t35 = ((int  (*)(char *, char *))t38)(t0, t31);

LAB93:    if (t35 != 0)
        goto LAB94;

LAB89:    t31 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t31);

LAB90:    t39 = (t0 + 6400);
    t40 = *((char **)t39);
    t39 = (t0 + 1280);
    t41 = (t0 + 6304);
    t42 = 0;
    xsi_delete_subprogram_invocation(t39, t40, t0, t41, t42);
    goto LAB1;

LAB63:    *((unsigned int *)t4) = 1;
    goto LAB65;

LAB64:    t20 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB65;

LAB66:    xsi_set_current_line(58, ng34);

LAB69:    xsi_set_current_line(59, ng34);
    xsi_vlogfile_write(0, 0, 1, ng35, 1, t0);
    xsi_set_current_line(59, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = ((char*)((ng31)));
    t5 = (t0 + 6304);
    t6 = (t0 + 2144);
    t19 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t19);
    t20 = (t0 + 5256);
    xsi_vlogvar_assign_value(t20, t4, 0, 0, 32);
    t26 = (t0 + 5416);
    xsi_vlogvar_assign_value(t26, t2, 0, 0, 6);

LAB72:    t27 = (t0 + 6400);
    t28 = *((char **)t27);
    t29 = (t28 + 80U);
    t30 = *((char **)t29);
    t31 = (t30 + 272U);
    t32 = *((char **)t31);
    t33 = (t32 + 0U);
    t34 = *((char **)t33);
    t35 = ((int  (*)(char *, char *))t34)(t0, t28);

LAB74:    if (t35 != 0)
        goto LAB75;

LAB70:    t28 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t28);

LAB71:    t36 = (t0 + 6400);
    t37 = *((char **)t36);
    t36 = (t0 + 2144);
    t38 = (t0 + 6304);
    t39 = 0;
    xsi_delete_subprogram_invocation(t36, t37, t0, t38, t39);
    xsi_set_current_line(59, ng34);
    xsi_vlogfile_write(1, 0, 0, ng36, 1, t0);
    xsi_set_current_line(60, ng34);
    xsi_vlogfile_write(1, 0, 0, ng40, 1, t0);
    xsi_set_current_line(61, ng34);
    t2 = (t0 + 3496);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memcpy(t4, t5, 8);
    t6 = ((char*)((ng7)));
    t19 = (t0 + 6304);
    t20 = (t0 + 1712);
    t26 = xsi_create_subprogram_invocation(t19, 0, t0, t20, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t20, t26);
    t27 = (t0 + 4616);
    xsi_vlogvar_assign_value(t27, t4, 0, 0, 8);
    t28 = (t0 + 4776);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 8);
    t29 = (t0 + 4936);
    xsi_vlogvar_assign_value_double(t29, 1.5000000000000000, 0);

LAB78:    t30 = (t0 + 6400);
    t31 = *((char **)t30);
    t32 = (t31 + 80U);
    t33 = *((char **)t32);
    t34 = (t33 + 272U);
    t36 = *((char **)t34);
    t37 = (t36 + 0U);
    t38 = *((char **)t37);
    t35 = ((int  (*)(char *, char *))t38)(t0, t31);

LAB80:    if (t35 != 0)
        goto LAB81;

LAB76:    t31 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t31);

LAB77:    t39 = (t0 + 6400);
    t40 = *((char **)t39);
    t39 = (t0 + 1712);
    t41 = (t0 + 6304);
    t42 = 0;
    xsi_delete_subprogram_invocation(t39, t40, t0, t41, t42);
    goto LAB68;

LAB73:;
LAB75:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB72;
    goto LAB1;

LAB79:;
LAB81:    t30 = (t0 + 6496U);
    *((char **)t30) = &&LAB78;
    goto LAB1;

LAB86:;
LAB88:    t27 = (t0 + 6496U);
    *((char **)t27) = &&LAB85;
    goto LAB1;

LAB92:;
LAB94:    t30 = (t0 + 6496U);
    *((char **)t30) = &&LAB91;
    goto LAB1;

}

static void Always_71_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 6744U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(72, ng34);
    t2 = (t0 + 6552);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(72, ng34);
    t4 = (t0 + 3336);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t0 + 3336);
    xsi_vlogvar_assign_value(t14, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

}


extern void work_m_00000000003870103882_3370072838_init()
{
	static char *pe[] = {(void *)Initial_26_0,(void *)Always_71_1};
	static char *se[] = {(void *)sp_exp_output,(void *)sp_succ_exit,(void *)sp_err_exit,(void *)sp_show_LEDs};
	xsi_register_didat("work_m_00000000003870103882_3370072838", "isim/test_ex1_isim_beh.exe.sim/work/m_00000000003870103882_3370072838.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
	xsi_register_subprogram_init(1, (void *)exp_output_varinit);
}
