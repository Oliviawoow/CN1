/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/student/Desktop/lab/lab06_skel/lab06_skel/ripple_carry_8bit_test.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {1U, 1U};
static int ng4[] = {127, 0};
static int ng5[] = {128, 0};
static int ng6[] = {4, 0};
static int ng7[] = {5, 0};



static void Initial_34_0(char *t0)
{
    char t9[8];
    char t10[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(34, ng0);

LAB4:    xsi_set_current_line(36, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1928);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(41, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1768);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t5, 8, t8, 8);
    memset(t10, 0, 8);
    t11 = (t3 + 4);
    t12 = (t9 + 4);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB9;

LAB6:    if (t22 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t10) = 1;

LAB9:    t26 = (t10 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(44, ng0);

LAB14:    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB12:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 99000LL);
    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB8:    t25 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(42, ng0);

LAB13:    xsi_set_current_line(43, ng0);
    t32 = ((char*)((ng2)));
    t33 = (t0 + 2088);
    xsi_vlogvar_assign_value(t33, t32, 0, 0, 1);
    goto LAB12;

LAB15:    xsi_set_current_line(49, ng0);
    t2 = ((char*)((ng2)));
    memset(t9, 0, 8);
    xsi_vlog_signed_unary_minus(t9, 32, t2, 32);
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t9, 0, 0, 8);
    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB16;
    goto LAB1;

LAB16:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1768);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t5, 8, t8, 8);
    memset(t10, 0, 8);
    t11 = (t3 + 4);
    t12 = (t9 + 4);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB20;

LAB17:    if (t22 != 0)
        goto LAB19;

LAB18:    *((unsigned int *)t10) = 1;

LAB20:    t26 = (t10 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB21;

LAB22:    xsi_set_current_line(55, ng0);

LAB25:    xsi_set_current_line(56, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB23:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 99000LL);
    *((char **)t1) = &&LAB26;
    goto LAB1;

LAB19:    t25 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB20;

LAB21:    xsi_set_current_line(53, ng0);

LAB24:    xsi_set_current_line(54, ng0);
    t32 = ((char*)((ng2)));
    t33 = (t0 + 2088);
    xsi_vlogvar_assign_value(t33, t32, 0, 0, 1);
    goto LAB23;

LAB26:    xsi_set_current_line(60, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB27:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1768);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t5, 8, t8, 8);
    memset(t10, 0, 8);
    t11 = (t3 + 4);
    t12 = (t9 + 4);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB31;

LAB28:    if (t22 != 0)
        goto LAB30;

LAB29:    *((unsigned int *)t10) = 1;

LAB31:    t26 = (t10 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB32;

LAB33:    xsi_set_current_line(66, ng0);

LAB36:    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB34:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 99000LL);
    *((char **)t1) = &&LAB37;
    goto LAB1;

LAB30:    t25 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB31;

LAB32:    xsi_set_current_line(64, ng0);

LAB35:    xsi_set_current_line(65, ng0);
    t32 = ((char*)((ng2)));
    t33 = (t0 + 2088);
    xsi_vlogvar_assign_value(t33, t32, 0, 0, 1);
    goto LAB34;

LAB37:    xsi_set_current_line(71, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(72, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB38:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1768);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t5, 8, t8, 8);
    memset(t10, 0, 8);
    t11 = (t3 + 4);
    t12 = (t9 + 4);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB42;

LAB39:    if (t22 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t10) = 1;

LAB42:    t26 = (t10 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB43;

LAB44:    xsi_set_current_line(77, ng0);

LAB47:    xsi_set_current_line(78, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB45:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 99000LL);
    *((char **)t1) = &&LAB48;
    goto LAB1;

LAB41:    t25 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB42;

LAB43:    xsi_set_current_line(75, ng0);

LAB46:    xsi_set_current_line(76, ng0);
    t32 = ((char*)((ng2)));
    t33 = (t0 + 2088);
    xsi_vlogvar_assign_value(t33, t32, 0, 0, 1);
    goto LAB45;

LAB48:    xsi_set_current_line(82, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(83, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB49;
    goto LAB1;

LAB49:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1768);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t5, 8, t8, 8);
    memset(t10, 0, 8);
    t11 = (t3 + 4);
    t12 = (t9 + 4);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB53;

LAB50:    if (t22 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t10) = 1;

LAB53:    t26 = (t10 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB54;

LAB55:    xsi_set_current_line(88, ng0);

LAB58:    xsi_set_current_line(89, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB56:    xsi_set_current_line(92, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 99000LL);
    *((char **)t1) = &&LAB59;
    goto LAB1;

LAB52:    t25 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB53;

LAB54:    xsi_set_current_line(86, ng0);

LAB57:    xsi_set_current_line(87, ng0);
    t32 = ((char*)((ng2)));
    t33 = (t0 + 2088);
    xsi_vlogvar_assign_value(t33, t32, 0, 0, 1);
    goto LAB56;

LAB59:    xsi_set_current_line(93, ng0);
    t2 = ((char*)((ng4)));
    memset(t9, 0, 8);
    xsi_vlog_signed_unary_minus(t9, 32, t2, 32);
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t9, 0, 0, 8);
    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng5)));
    memset(t9, 0, 8);
    xsi_vlog_signed_unary_minus(t9, 32, t2, 32);
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t9, 0, 0, 8);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB60;
    goto LAB1;

LAB60:    xsi_set_current_line(97, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = (t0 + 1608);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 1768);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 8, t6, 8, t11, 8);
    memset(t10, 0, 8);
    t12 = (t4 + 4);
    t25 = (t9 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t12);
    t17 = *((unsigned int *)t25);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t12);
    t21 = *((unsigned int *)t25);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB64;

LAB61:    if (t22 != 0)
        goto LAB63;

LAB62:    *((unsigned int *)t10) = 1;

LAB64:    t32 = (t10 + 4);
    t27 = *((unsigned int *)t32);
    t28 = (~(t27));
    t29 = *((unsigned int *)t10);
    t30 = (t29 & t28);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB65;

LAB66:    xsi_set_current_line(99, ng0);

LAB69:    xsi_set_current_line(100, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB67:    goto LAB1;

LAB63:    t26 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB64;

LAB65:    xsi_set_current_line(97, ng0);

LAB68:    xsi_set_current_line(98, ng0);
    t33 = ((char*)((ng2)));
    t34 = (t0 + 2088);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 1);
    goto LAB67;

}


extern void work_m_00000000003212802258_0491635576_init()
{
	static char *pe[] = {(void *)Initial_34_0};
	xsi_register_didat("work_m_00000000003212802258_0491635576", "isim/ripple_carry_8bit_test_isim_beh.exe.sim/work/m_00000000003212802258_0491635576.didat");
	xsi_register_executes(pe);
}
