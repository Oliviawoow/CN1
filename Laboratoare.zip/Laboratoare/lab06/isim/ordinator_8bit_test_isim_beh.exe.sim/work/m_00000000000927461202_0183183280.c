/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/student/Desktop/lab/lab06_skel/lab06_skel/ordinator_8bit_test.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 1U};
static int ng3[] = {1, 0};
static int ng4[] = {10, 0};
static int ng5[] = {2, 0};
static unsigned int ng6[] = {1U, 1U};
static int ng7[] = {12, 0};
static int ng8[] = {22, 0};
static int ng9[] = {254, 0};
static int ng10[] = {34, 0};
static int ng11[] = {7, 0};
static int ng12[] = {251, 0};
static int ng13[] = {5, 0};
static int ng14[] = {15, 0};
static int ng15[] = {8, 0};



static void Always_33_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 2816);
    xsi_process_wait(t2, 500LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(34, ng0);
    t4 = (t0 + 1928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 1928);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_36_1(char *t0)
{
    char t16[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;

LAB0:    t1 = (t0 + 3256U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);

LAB4:    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1928);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(42, ng0);
    t2 = (t0 + 3576);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(46, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(46, ng0);

LAB6:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB8;

LAB7:    t4 = (t0 + 3592);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB6;
    goto LAB1;

LAB8:    t11 = (t0 + 3592);
    *((int *)t11) = 0;
    xsi_set_current_line(46, ng0);
    t12 = (t0 + 3608);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(48, ng0);
    t14 = ((char*)((ng4)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(48, ng0);

LAB10:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB12;

LAB11:    t4 = (t0 + 3624);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB10;
    goto LAB1;

LAB12:    t11 = (t0 + 3624);
    *((int *)t11) = 0;
    xsi_set_current_line(48, ng0);
    t12 = (t0 + 3640);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(49, ng0);
    t14 = ((char*)((ng5)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 3656);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(50, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng4)));
    memset(t16, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t17 = (t9 ^ t10);
    t18 = (t8 | t17);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB18;

LAB15:    if (t21 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t16) = 1;

LAB18:    t14 = (t16 + 4);
    t24 = *((unsigned int *)t14);
    t25 = (~(t24));
    t26 = *((unsigned int *)t16);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB19;

LAB20:    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB21:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 3672);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB22;
    goto LAB1;

LAB17:    t13 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB18;

LAB19:    xsi_set_current_line(50, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 2088);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 1);
    goto LAB21;

LAB22:    xsi_set_current_line(52, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2088);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 3688);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB23:    xsi_set_current_line(58, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(58, ng0);

LAB24:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB26;

LAB25:    t4 = (t0 + 3704);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB24;
    goto LAB1;

LAB26:    t11 = (t0 + 3704);
    *((int *)t11) = 0;
    xsi_set_current_line(58, ng0);
    t12 = (t0 + 3720);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB27:    xsi_set_current_line(60, ng0);
    t14 = ((char*)((ng4)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(60, ng0);

LAB28:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB30;

LAB29:    t4 = (t0 + 3736);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB28;
    goto LAB1;

LAB30:    t11 = (t0 + 3736);
    *((int *)t11) = 0;
    xsi_set_current_line(60, ng0);
    t12 = (t0 + 3752);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB31:    xsi_set_current_line(61, ng0);
    t14 = ((char*)((ng1)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(61, ng0);

LAB32:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB34;

LAB33:    t4 = (t0 + 3768);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB32;
    goto LAB1;

LAB34:    t11 = (t0 + 3768);
    *((int *)t11) = 0;
    xsi_set_current_line(61, ng0);
    t12 = (t0 + 3784);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB35:    xsi_set_current_line(62, ng0);
    t14 = ((char*)((ng7)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(62, ng0);

LAB36:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB38;

LAB37:    t4 = (t0 + 3800);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB36;
    goto LAB1;

LAB38:    t11 = (t0 + 3800);
    *((int *)t11) = 0;
    xsi_set_current_line(62, ng0);
    t12 = (t0 + 3816);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB39;
    goto LAB1;

LAB39:    xsi_set_current_line(63, ng0);
    t14 = ((char*)((ng5)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3832);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB40;
    goto LAB1;

LAB40:    xsi_set_current_line(64, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng8)));
    memset(t16, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t17 = (t9 ^ t10);
    t18 = (t8 | t17);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB44;

LAB41:    if (t21 != 0)
        goto LAB43;

LAB42:    *((unsigned int *)t16) = 1;

LAB44:    t14 = (t16 + 4);
    t24 = *((unsigned int *)t14);
    t25 = (~(t24));
    t26 = *((unsigned int *)t16);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB45;

LAB46:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB47:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 3848);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB48;
    goto LAB1;

LAB43:    t13 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB44;

LAB45:    xsi_set_current_line(64, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 2088);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 1);
    goto LAB47;

LAB48:    xsi_set_current_line(66, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2088);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 3864);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB49;
    goto LAB1;

LAB49:    xsi_set_current_line(71, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(71, ng0);

LAB50:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB52;

LAB51:    t4 = (t0 + 3880);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB50;
    goto LAB1;

LAB52:    t11 = (t0 + 3880);
    *((int *)t11) = 0;
    xsi_set_current_line(71, ng0);
    t12 = (t0 + 3896);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB53;
    goto LAB1;

LAB53:    xsi_set_current_line(73, ng0);
    t14 = ((char*)((ng4)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(73, ng0);

LAB54:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB56;

LAB55:    t4 = (t0 + 3912);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB54;
    goto LAB1;

LAB56:    t11 = (t0 + 3912);
    *((int *)t11) = 0;
    xsi_set_current_line(73, ng0);
    t12 = (t0 + 3928);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB57;
    goto LAB1;

LAB57:    xsi_set_current_line(74, ng0);
    t14 = ((char*)((ng3)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(74, ng0);

LAB58:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB60;

LAB59:    t4 = (t0 + 3944);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB58;
    goto LAB1;

LAB60:    t11 = (t0 + 3944);
    *((int *)t11) = 0;
    xsi_set_current_line(74, ng0);
    t12 = (t0 + 3960);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB61;
    goto LAB1;

LAB61:    xsi_set_current_line(75, ng0);
    t14 = ((char*)((ng7)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(75, ng0);

LAB62:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB64;

LAB63:    t4 = (t0 + 3976);
    *((int *)t4) = 1;
    t5 = (t0 + 3256U);
    *((char **)t5) = &&LAB62;
    goto LAB1;

LAB64:    t11 = (t0 + 3976);
    *((int *)t11) = 0;
    xsi_set_current_line(75, ng0);
    t12 = (t0 + 3992);
    *((int *)t12) = 1;
    t13 = (t0 + 3288);
    *((char **)t13) = t12;
    *((char **)t1) = &&LAB65;
    goto LAB1;

LAB65:    xsi_set_current_line(76, ng0);
    t14 = ((char*)((ng5)));
    t15 = (t0 + 1608);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 4008);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB66;
    goto LAB1;

LAB66:    xsi_set_current_line(77, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng9)));
    memset(t16, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t17 = (t9 ^ t10);
    t18 = (t8 | t17);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB70;

LAB67:    if (t21 != 0)
        goto LAB69;

LAB68:    *((unsigned int *)t16) = 1;

LAB70:    t14 = (t16 + 4);
    t24 = *((unsigned int *)t14);
    t25 = (~(t24));
    t26 = *((unsigned int *)t16);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB71;

LAB72:    xsi_set_current_line(77, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB73:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 4024);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB74;
    goto LAB1;

LAB69:    t13 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB70;

LAB71:    xsi_set_current_line(77, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 2088);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 1);
    goto LAB73;

LAB74:    xsi_set_current_line(79, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2088);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(80, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 4040);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB75;
    goto LAB1;

LAB75:    xsi_set_current_line(85, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB76;
    goto LAB1;

LAB76:    xsi_set_current_line(85, ng0);

LAB77:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB79;

LAB78:    t5 = (t0 + 4056);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB77;
    goto LAB1;

LAB79:    t12 = (t0 + 4056);
    *((int *)t12) = 0;
    xsi_set_current_line(85, ng0);
    t13 = (t0 + 4072);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB80;
    goto LAB1;

LAB80:    xsi_set_current_line(87, ng0);
    t15 = ((char*)((ng4)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB81;
    goto LAB1;

LAB81:    xsi_set_current_line(87, ng0);

LAB82:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB84;

LAB83:    t5 = (t0 + 4088);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB82;
    goto LAB1;

LAB84:    t12 = (t0 + 4088);
    *((int *)t12) = 0;
    xsi_set_current_line(87, ng0);
    t13 = (t0 + 4104);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB85;
    goto LAB1;

LAB85:    xsi_set_current_line(88, ng0);
    t15 = ((char*)((ng1)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB86;
    goto LAB1;

LAB86:    xsi_set_current_line(88, ng0);

LAB87:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB89;

LAB88:    t5 = (t0 + 4120);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB87;
    goto LAB1;

LAB89:    t12 = (t0 + 4120);
    *((int *)t12) = 0;
    xsi_set_current_line(88, ng0);
    t13 = (t0 + 4136);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB90;
    goto LAB1;

LAB90:    xsi_set_current_line(89, ng0);
    t15 = ((char*)((ng7)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(89, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB91;
    goto LAB1;

LAB91:    xsi_set_current_line(89, ng0);

LAB92:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB94;

LAB93:    t5 = (t0 + 4152);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB92;
    goto LAB1;

LAB94:    t12 = (t0 + 4152);
    *((int *)t12) = 0;
    xsi_set_current_line(89, ng0);
    t13 = (t0 + 4168);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB95;
    goto LAB1;

LAB95:    xsi_set_current_line(90, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB96;
    goto LAB1;

LAB96:    xsi_set_current_line(90, ng0);

LAB97:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB99;

LAB98:    t5 = (t0 + 4184);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB97;
    goto LAB1;

LAB99:    t12 = (t0 + 4184);
    *((int *)t12) = 0;
    xsi_set_current_line(90, ng0);
    t13 = (t0 + 4200);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB100;
    goto LAB1;

LAB100:    xsi_set_current_line(91, ng0);
    t15 = ((char*)((ng10)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB101;
    goto LAB1;

LAB101:    xsi_set_current_line(91, ng0);

LAB102:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB104;

LAB103:    t5 = (t0 + 4216);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB102;
    goto LAB1;

LAB104:    t12 = (t0 + 4216);
    *((int *)t12) = 0;
    xsi_set_current_line(91, ng0);
    t13 = (t0 + 4232);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB105;
    goto LAB1;

LAB105:    xsi_set_current_line(92, ng0);
    t15 = ((char*)((ng1)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB106;
    goto LAB1;

LAB106:    xsi_set_current_line(92, ng0);

LAB107:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB109;

LAB108:    t5 = (t0 + 4248);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB107;
    goto LAB1;

LAB109:    t12 = (t0 + 4248);
    *((int *)t12) = 0;
    xsi_set_current_line(92, ng0);
    t13 = (t0 + 4264);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB110;
    goto LAB1;

LAB110:    xsi_set_current_line(93, ng0);
    t15 = ((char*)((ng11)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB111;
    goto LAB1;

LAB111:    xsi_set_current_line(93, ng0);

LAB112:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB114;

LAB113:    t5 = (t0 + 4280);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB112;
    goto LAB1;

LAB114:    t12 = (t0 + 4280);
    *((int *)t12) = 0;
    xsi_set_current_line(93, ng0);
    t13 = (t0 + 4296);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB115;
    goto LAB1;

LAB115:    xsi_set_current_line(94, ng0);
    t15 = ((char*)((ng5)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 4312);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB116;
    goto LAB1;

LAB116:    xsi_set_current_line(95, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng12)));
    memset(t16, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t17 = (t9 ^ t10);
    t18 = (t8 | t17);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB120;

LAB117:    if (t21 != 0)
        goto LAB119;

LAB118:    *((unsigned int *)t16) = 1;

LAB120:    t14 = (t16 + 4);
    t24 = *((unsigned int *)t14);
    t25 = (~(t24));
    t26 = *((unsigned int *)t16);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB121;

LAB122:    xsi_set_current_line(95, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB123:    xsi_set_current_line(95, ng0);
    t2 = (t0 + 4328);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB124;
    goto LAB1;

LAB119:    t13 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB120;

LAB121:    xsi_set_current_line(95, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 2088);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 1);
    goto LAB123;

LAB124:    xsi_set_current_line(97, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2088);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 4344);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB125;
    goto LAB1;

LAB125:    xsi_set_current_line(103, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB126;
    goto LAB1;

LAB126:    xsi_set_current_line(103, ng0);

LAB127:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB129;

LAB128:    t5 = (t0 + 4360);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB127;
    goto LAB1;

LAB129:    t12 = (t0 + 4360);
    *((int *)t12) = 0;
    xsi_set_current_line(103, ng0);
    t13 = (t0 + 4376);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB130;
    goto LAB1;

LAB130:    xsi_set_current_line(105, ng0);
    t15 = ((char*)((ng4)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB131;
    goto LAB1;

LAB131:    xsi_set_current_line(105, ng0);

LAB132:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB134;

LAB133:    t5 = (t0 + 4392);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB132;
    goto LAB1;

LAB134:    t12 = (t0 + 4392);
    *((int *)t12) = 0;
    xsi_set_current_line(105, ng0);
    t13 = (t0 + 4408);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB135;
    goto LAB1;

LAB135:    xsi_set_current_line(106, ng0);
    t15 = ((char*)((ng13)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(106, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB136;
    goto LAB1;

LAB136:    xsi_set_current_line(106, ng0);

LAB137:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB139;

LAB138:    t5 = (t0 + 4424);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB137;
    goto LAB1;

LAB139:    t12 = (t0 + 4424);
    *((int *)t12) = 0;
    xsi_set_current_line(106, ng0);
    t13 = (t0 + 4440);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB140;
    goto LAB1;

LAB140:    xsi_set_current_line(107, ng0);
    t15 = ((char*)((ng1)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(107, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB141;
    goto LAB1;

LAB141:    xsi_set_current_line(107, ng0);

LAB142:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB144;

LAB143:    t5 = (t0 + 4456);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB142;
    goto LAB1;

LAB144:    t12 = (t0 + 4456);
    *((int *)t12) = 0;
    xsi_set_current_line(107, ng0);
    t13 = (t0 + 4472);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB145;
    goto LAB1;

LAB145:    xsi_set_current_line(108, ng0);
    t15 = ((char*)((ng7)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB146;
    goto LAB1;

LAB146:    xsi_set_current_line(108, ng0);

LAB147:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB149;

LAB148:    t5 = (t0 + 4488);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB147;
    goto LAB1;

LAB149:    t12 = (t0 + 4488);
    *((int *)t12) = 0;
    xsi_set_current_line(108, ng0);
    t13 = (t0 + 4504);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB150;
    goto LAB1;

LAB150:    xsi_set_current_line(109, ng0);
    t15 = ((char*)((ng14)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB151;
    goto LAB1;

LAB151:    xsi_set_current_line(109, ng0);

LAB152:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB154;

LAB153:    t5 = (t0 + 4520);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB152;
    goto LAB1;

LAB154:    t12 = (t0 + 4520);
    *((int *)t12) = 0;
    xsi_set_current_line(109, ng0);
    t13 = (t0 + 4536);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB155;
    goto LAB1;

LAB155:    xsi_set_current_line(110, ng0);
    t15 = ((char*)((ng15)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB156;
    goto LAB1;

LAB156:    xsi_set_current_line(110, ng0);

LAB157:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB159;

LAB158:    t5 = (t0 + 4552);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB157;
    goto LAB1;

LAB159:    t12 = (t0 + 4552);
    *((int *)t12) = 0;
    xsi_set_current_line(110, ng0);
    t13 = (t0 + 4568);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB160;
    goto LAB1;

LAB160:    xsi_set_current_line(111, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB161;
    goto LAB1;

LAB161:    xsi_set_current_line(111, ng0);

LAB162:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB164;

LAB163:    t5 = (t0 + 4584);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB162;
    goto LAB1;

LAB164:    t12 = (t0 + 4584);
    *((int *)t12) = 0;
    xsi_set_current_line(111, ng0);
    t13 = (t0 + 4600);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB165;
    goto LAB1;

LAB165:    xsi_set_current_line(112, ng0);
    t15 = ((char*)((ng10)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(112, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB166;
    goto LAB1;

LAB166:    xsi_set_current_line(112, ng0);

LAB167:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB169;

LAB168:    t5 = (t0 + 4616);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB167;
    goto LAB1;

LAB169:    t12 = (t0 + 4616);
    *((int *)t12) = 0;
    xsi_set_current_line(112, ng0);
    t13 = (t0 + 4632);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB170;
    goto LAB1;

LAB170:    xsi_set_current_line(113, ng0);
    t15 = ((char*)((ng1)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(113, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB171;
    goto LAB1;

LAB171:    xsi_set_current_line(113, ng0);

LAB172:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB174;

LAB173:    t5 = (t0 + 4648);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB172;
    goto LAB1;

LAB174:    t12 = (t0 + 4648);
    *((int *)t12) = 0;
    xsi_set_current_line(113, ng0);
    t13 = (t0 + 4664);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB175;
    goto LAB1;

LAB175:    xsi_set_current_line(114, ng0);
    t15 = ((char*)((ng11)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(114, ng0);
    t2 = (t0 + 3064);
    xsi_process_wait(t2, 10LL);
    *((char **)t1) = &&LAB176;
    goto LAB1;

LAB176:    xsi_set_current_line(114, ng0);

LAB177:    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB179;

LAB178:    t5 = (t0 + 4680);
    *((int *)t5) = 1;
    t11 = (t0 + 3256U);
    *((char **)t11) = &&LAB177;
    goto LAB1;

LAB179:    t12 = (t0 + 4680);
    *((int *)t12) = 0;
    xsi_set_current_line(114, ng0);
    t13 = (t0 + 4696);
    *((int *)t13) = 1;
    t14 = (t0 + 3288);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB180;
    goto LAB1;

LAB180:    xsi_set_current_line(115, ng0);
    t15 = ((char*)((ng5)));
    t29 = (t0 + 1608);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 8);
    xsi_set_current_line(115, ng0);
    t2 = (t0 + 4712);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB181;
    goto LAB1;

LAB181:    xsi_set_current_line(116, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng12)));
    memset(t16, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t17 = (t9 ^ t10);
    t18 = (t8 | t17);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB185;

LAB182:    if (t21 != 0)
        goto LAB184;

LAB183:    *((unsigned int *)t16) = 1;

LAB185:    t14 = (t16 + 4);
    t24 = *((unsigned int *)t14);
    t25 = (~(t24));
    t26 = *((unsigned int *)t16);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB186;

LAB187:    xsi_set_current_line(116, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB188:    xsi_set_current_line(116, ng0);
    t2 = (t0 + 4728);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB189;
    goto LAB1;

LAB184:    t13 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB185;

LAB186:    xsi_set_current_line(116, ng0);
    t15 = ((char*)((ng3)));
    t29 = (t0 + 2088);
    xsi_vlogvar_assign_value(t29, t15, 0, 0, 1);
    goto LAB188;

LAB189:    xsi_set_current_line(118, ng0);
    xsi_vlog_stop(1);
    goto LAB1;

}


extern void work_m_00000000000927461202_0183183280_init()
{
	static char *pe[] = {(void *)Always_33_0,(void *)Initial_36_1};
	xsi_register_didat("work_m_00000000000927461202_0183183280", "isim/ordinator_8bit_test_isim_beh.exe.sim/work/m_00000000000927461202_0183183280.didat");
	xsi_register_executes(pe);
}
